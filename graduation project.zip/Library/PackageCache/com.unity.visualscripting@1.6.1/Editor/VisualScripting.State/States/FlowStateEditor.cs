namespace Unity.VisualScripting
{
    [Editor(typeof(FlowState))]
    public sealed class FlowStateEditor : NesterStateEditor
    {
        public FlowStateEditor(Metadata metadata) : base(metadata) { }
    }
}
