namespace Unity.VisualScripting
{
    [Editor(typeof(SuperState))]
    public sealed class SuperStateEditor : NesterStateEditor
    {
        public SuperStateEditor(Metadata metadata) : base(metadata) { }
    }
}
