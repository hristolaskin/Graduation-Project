namespace Unity.VisualScripting
{
    public sealed class StateDescription : GraphElementDescription
    {
    }
}
