namespace Unity.VisualScripting
{
    [Editor(typeof(FlowStateTransition))]
    public sealed class FlowStateTransitionEditor : NesterStateTransitionEditor
    {
        public FlowStateTransitionEditor(Metadata metadata) : base(metadata) { }
    }
}
