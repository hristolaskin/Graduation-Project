namespace Unity.VisualScripting
{
    public static class IconSize
    {
        public const int Small = 16;
        public const int Medium = 32;
        public const int Large = 64;
    }
}
