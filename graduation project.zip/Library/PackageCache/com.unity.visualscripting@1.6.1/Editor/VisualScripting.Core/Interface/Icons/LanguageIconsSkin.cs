namespace Unity.VisualScripting
{
    public enum LanguageIconsSkin
    {
        VisualStudioColor,
        VisualStudioMonochrome
    }
}
