namespace Unity.VisualScripting
{
    public enum ParameterStringMode
    {
        Types,
        Names
    }
}
