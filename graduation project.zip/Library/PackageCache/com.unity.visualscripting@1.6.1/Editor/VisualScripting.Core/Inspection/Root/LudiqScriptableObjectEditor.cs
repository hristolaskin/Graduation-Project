using UnityEditor;

namespace Unity.VisualScripting
{
    [CustomEditor(typeof(LudiqScriptableObject), true)]
    public class LudiqScriptableObjectEditor : LudiqRootObjectEditor { }
}
