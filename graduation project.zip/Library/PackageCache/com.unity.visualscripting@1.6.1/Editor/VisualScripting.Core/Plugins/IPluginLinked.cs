namespace Unity.VisualScripting
{
    public interface IPluginLinked
    {
        Plugin plugin { get; }
    }
}
