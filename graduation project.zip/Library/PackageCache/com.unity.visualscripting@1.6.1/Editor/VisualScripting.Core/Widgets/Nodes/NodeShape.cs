namespace Unity.VisualScripting
{
    public enum NodeShape
    {
        Square,
        Hex
    }
}
