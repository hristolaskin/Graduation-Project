namespace Unity.VisualScripting
{
    public class GraphDescription : Description, IGraphDescription { }
}
